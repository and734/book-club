const express = require('express');
const path = require('path');
const favicon = require('serve-favicon');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const csrf = require('csurf');

// Load routes (move these *inside* the .then() later)
// var index = require('./routes/index');
// var users = require('./routes/UserRoutes');
// var userAPI = require('./routes/UserAPI');
// var books = require('./routes/BookRoutes');

const app = express();

// Load .env file
require('dotenv').config();

const passport = require('passport');
const session = require('express-session');
const flash = require('connect-flash');
const mongoose = require('mongoose');
const configDB = require('./config/database');
const MongoStore = require('connect-mongo');

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Database connection (and EVERYTHING else)
mongoose.Promise = global.Promise;

mongoose.connect(configDB.url)
  .then(m => {
    console.log("Your awesome Database is connected on");
    console.log(configDB.url);

    // --- EVERYTHING ELSE GOES INSIDE HERE ---

    // Load routes (now they're inside the .then())
    var index = require('./routes/index');
    var users = require('./routes/UserRoutes');
    var userAPI = require('./routes/UserAPI');
    var books = require('./routes/BookRoutes');

    // Passport configuration (inside the .then())
    require('./config/passport')(passport);

    app.use(session({
      secret: 'algeriannewbieStemplate',
      name: 'itismysessions',
      resave: false,
      saveUninitialized: false,
      store: MongoStore.create({
        clientPromise: Promise.resolve(m.connection.getClient()) // Use Promise.resolve
      })
    }));

    app.use(passport.initialize());
    app.use(passport.session());
    app.use(flash());

    // To enable CORS
    app.use(function(req, res, next) {
      res.header("Access-Control-Allow-Origin", "*");
      res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
      next();
    });

    app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
    app.use(logger('dev'));
    app.use(express.json());
    app.use(express.urlencoded({ extended: false }));
    app.use(cookieParser());
    app.use(express.static(path.join(__dirname, 'public')));
    app.use(helmet());
    app.use(csrf());
    app.use(function(req, res, next){
      res.locals.csrftoken = req.csrfToken();
      next();
    });

    app.use('/', index);
    app.use('/users', users);
    app.use('/api/users', userAPI);
    app.use('/books', books);

    // catch 404 and forward to error handler
    app.use(function(req, res, next) {
      var err = new Error('Not Found');
      err.status = 404;
      next(err);
    });

    // error handler
    app.use(function(err, req, res, next) {
      // set locals, only providing error in development
      res.locals.message = err.message;
      res.locals.error = req.app.get('env') === 'development' ? err : {};

      // render the error page
      res.status(err.status || 500);
      res.render('error');
    });

    // --- END OF EVERYTHING INSIDE .then() ---
  })
  .catch(err => {
    console.error("Failed to load DB", err);
  });

// If the connection throws an error (keep this, but it's less likely to be triggered now)
mongoose.connection.on('error', function(err) {
  console.log('Mongoose connection Warning: error: ' + err);
});

// When the connection is disconnected
mongoose.connection.on('disconnected', function() {
  console.log('Mongoose connection Warning: disconnected');
});
module.exports = app;
