const express = require('express');
const router = express.Router();
const userController = require('../controllers/UserController.js');

// GET all users (for listing, probably an admin-only route in a real app)
router.get('/', userController.list);

// GET a specific user by ID (usually for public profiles, etc.)
router.get('/:id', userController.show);

// POST request to check if an email is already in use (for signup forms)
router.post('/get-user-by-mail', userController.checkLocalMailController);

// Removed: POST / to create a user - Use Passport's local-signup for this!

// --- Routes that likely require authentication (using your isLoggedIn middleware) ---

// Assuming you have an isLoggedIn middleware (as discussed before)
const { isLoggedIn } = require('../routes/helperFunctions.js'); // Adjust path if needed

// GET the logged-in user's profile
// Note: No :id parameter here. We get the ID from req.user
router.get('/profile', isLoggedIn, userController.showProfile);

// GET the form to edit the logged-in user's profile
router.get('/profile/edit', isLoggedIn, userController.editProfile);

// POST request to update the logged-in user's profile
router.post('/profile/edit', isLoggedIn, userController.applyProfileEdition);

module.exports = router;
