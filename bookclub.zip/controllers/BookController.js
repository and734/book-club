var BookModel = require('../models/BookModel.js');
var UserModel = require('../models/UserModel.js'); // You might not need this here, depending on your usage

/**
 * BookController.js
 *
 * @description :: Server-side logic for managing Books.
 */
module.exports = {
    /**
     * BookController.list()
     */
    list: async function (req, res, next) { // Use async/await
        try {
            const books = await BookModel.find({}); // Await the promise
            return res.render('books/all', { user: req.user, books: books });
        } catch (err) {
            return res.status(500).json({
                message: 'Error when getting Book.',
                error: err
            });
            // Better: pass to error handler: next(err);
        }
    },

    myBooksController: async function (req, res, next) {
        try {
            const books = await BookModel.find({ owner: req.user, requesters: { $not: { $size: 0 } } });
            return res.render('books/my-books', { user: req.user, books: books });
        } catch (err) {
             return res.status(500).json({
                  message: 'Error when getting Book.',
                  error: err
              });
            //next(err)
        }
    },

    addNewBook: async function (req, res, next) {
        try {
            const book = new BookModel();
            book.title = req.body.title;
            book.imgUrl = req.body.image;
            book.owner = req.user;

            await book.save(); // Await the save operation
            return res.redirect('/books/');
        } catch (err) {
            return res.status(500).json({
                message: 'Error when creating Book.',
                error: err
            });
            //next(err)
        }
    },

    requestBook: async function (req, res, next) {
        const id = req.params.id;
        const user = req.user;
        try {
            const book = await BookModel.findOne({ _id: id });
             if (!book) {
                return res.status(404).json({ message: 'Book not found' }); // Handle not found
            }
            book.requesters.push(user);
            await book.save();
            return res.redirect('/books/');
        } catch (err) {
            return res.status(500).json({
                message: 'Error when requesting/saving Book.',
                error: err
            });
            //next(err)
        }
    },

    acceptRequest: async function (req, res, next) {
        const id = req.params.bookId;
        const requester = req.params.requesterID;
        try {
            const book = await BookModel.findOne({ _id: id, owner: req.user });
             if (!book) {
                return res.status(404).json({message: 'Book not found or you are not the owner'});
            }
            book.giveToUser(requester); // Assuming giveToUser is a method on your BookModel
            await book.save();
            return res.redirect('/books/');
        } catch (err) {
          return res.status(500).json({
                message: 'Error when accepting request/saving Book.',
                error: err
            });
            //next(err)
        }
    },

    userTrades: async function (req, res, next) {
        try {
            const books = await BookModel.find({ requesters: req.user._id });
            return res.render('books/trades', { user: req.user, pending: books });
        } catch (err) {
            return res.status(500).json({
                  message: 'Error when getting Book.',
                  error: err
              });
              //next(err)
        }
    },

    show: async function (req, res, next) {
      //This function seems to get all books, not just one. It also returns JSON, not a view.
      //It seems like you may have meant this to be an "index" function, so I will rewrite it that way
        try {
            const books = await BookModel.find();
             if (!books) {
                return res.status(404).json({message: 'No books found'});
            }
            return res.json(books);
        } catch (err) {
            return res.status(500).json({
                    message: 'Error when getting Book.',
                    error: err
                });
              //next(err)
        }
    },
};
