var UserModel = require('../models/UserModel.js');

/**
 * UserController.js
 *
 * @description :: Server-side logic for managing Users.
 */
module.exports = {
    /**
     * UserController.showProfile()
     */
     showProfile: async function (req, res, next) {
      try {
        // Use req.user._id, not req.params.id, for the logged-in user's profile
        const user = await UserModel.findById(req.user._id);
        if (!user) {
          // If no user, redirect to login (or handle as appropriate)
          return res.redirect('/login');
        }
        return res.render('user/profile', { title: "Welcome", user: user, loggedUser: req.user });
      } catch (err) {
        next(err); // Pass errors to the Express error handler
      }
    },

    /**
     * UserController.list()
     */
    list: async function (req, res, next) {
        try {
            const users = await UserModel.find();
            return res.json(users);
        } catch (err) {
           next(err)
        }
    },

    /**
     * UserController.show()
     */
    show: async function (req, res, next) {
        const id = req.params.id;
        try {
            const user = await UserModel.findById(id);
            if (!user) {
                return res.status(404).json({
                    message: 'No such User'
                });
            }
            return res.json(user);
        } catch (err) {
            next(err)
        }
    },

    /**
     * UserController.create()
     */
     //This create method is likely not how you want to create users.  You should use Passport for user creation
     //This function does not take any data and thus can't create a user. It also does not hash a password.
     //Remove this, and rely on passport for the user creation.
    /*create: async function (req, res) {
        try {
          const user = new UserModel({}); // This creates an empty user!
          await user.save()
          return res.status(201).json(user);
        }
        catch(err) {
            next(err);
        }

    },*/

    /**
    * Check if email is already used
    */
    checkLocalMailController: async function (req, res, next) {
      const email = req.body.email;
      try {
        const user = await UserModel.findOne({ $or: [{ 'local.email': email }, { 'facebook.email': email }, { 'twitter.email': email }] }); // Check all email fields

        if (user) {
           // Return a simplified user object.  Don't expose sensitive data.
          return res.status(200).json({ name: user.profile.name, img: user.profile.pictureUrl });
        } else {
          return res.status(200).json(null); // Explicitly return null if no user found
        }
      } catch (err) {
        next(err)
      }
    },

    /**
      * Edit profile, change name and picture and city/state
      */
    editProfile: async function(req, res, next){
        try {
            const user = await UserModel.findById(req.user._id);
             if (!user) {
                return res.redirect('/login'); // Or a 404
            }
            res.render('user/edit', {
                title: "Edit "+ user.profile.name+"'s profile",
                user: user
            });
        }
        catch (err) {
            next(err);
        }
    },
    applyProfileEdition: async function(req, res, next){
      const id = req.user._id; // Use req.user._id for the logged-in user
      try {
        const user = await UserModel.findById(id);
        if (!user) {
          return res.status(404).json({ // Or redirect, depending on your needs
            message: 'User not found'
          });
        }

        // Use Object.assign to update the user object.  This is cleaner.
        Object.assign(user.profile, {
          name: req.body.name || user.profile.name,  // Keep existing values if not provided
          pictureUrl: req.body.pictureUrl || user.profile.pictureUrl,
          city: req.body.city || user.profile.city,
          state: req.body.state || user.profile.state
        });

        await user.save();
        res.redirect('/users/profile'); // Redirect to the profile page
      } catch (err) {
          if (err.name === 'ValidationError') { //Mongoose validation error
                return res.render('user/edit', {
                    title: "Edit "+ req.user.profile.name+"'s profile",
                    user: user,
                    errors: err.errors
                });
          }
        next(err);
      }
    },
};


